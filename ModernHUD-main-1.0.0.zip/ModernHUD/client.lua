local ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    UpdateJob(xPlayer.job.name, xPlayer.job.grade_label or xPlayer.job.grade)
    SendNUIMessage({ type = "hud:show" })
end)

RegisterNetEvent('esx:setJob', function(job)
    UpdateJob(job.name, job.grade_label or job.grade)
end)

function UpdateJob(jobName, jobGrade)
    SendNUIMessage({
        type = "hud:updateJob",
        job = jobName,
        grade = jobGrade,
    })
end

CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local health = GetEntityHealth(ped) - 100
        local armor = GetPedArmour(ped)
        
        local thirst, hunger = 0, 0
        TriggerEvent('esx_status:getStatus', 'thirst', function(status)
            thirst = math.floor(status.getPercent())
        end)
        TriggerEvent('esx_status:getStatus', 'hunger', function(status)
            hunger = math.floor(status.getPercent())
        end)

        SendNUIMessage({
            type = "hud:updateStats",
            values = {
                health = health,
                armor = armor,
                thirst = thirst,
                hunger = hunger
            }
        })
    end
end)
