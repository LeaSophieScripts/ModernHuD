fx_version 'cerulean'
game 'gta5'

author 'Lea Sophie'
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/img/jobs/*.png'
}

client_scripts {
    'client.lua'
}