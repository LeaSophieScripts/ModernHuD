Made by Lea Sophie aka Sophie Scripts
  
  Selling/Reuploading is not permitted

  Any questions 

  Discord: burnedwitchy


  Put it in your Resources folder

  then server.cfg and there you do "ensure ModernHUD"


  For Adding new job images, just copy one of them, rename it to the job what name is it, and replace the picture in the image, and drag n drop it back to html -> img -> jobs

  After that you need to Restart your Server and there you have youre new Job Name