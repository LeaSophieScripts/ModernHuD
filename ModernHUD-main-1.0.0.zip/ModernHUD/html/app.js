const LOCAL_ICON_PATH = "img/jobs/";

function setJobIcon(jobName) {
    if (!jobName) {
        document.getElementById('jobIcon').src = LOCAL_ICON_PATH + "default.png";
        return;
    }
    const iconPath = `${LOCAL_ICON_PATH}${jobName.toLowerCase()}.png`;
    fetch(iconPath)
        .then(res => {
            if (res.ok) {
                document.getElementById('jobIcon').src = iconPath;
            } else {
                document.getElementById('jobIcon').src = LOCAL_ICON_PATH + "default.png";
            }
        })
        .catch(() => {
            document.getElementById('jobIcon').src = LOCAL_ICON_PATH + "default.png";
        });
}

window.addEventListener('message', (event) => {
    const data = event.data || {};
    switch (data.type) {
        case 'hud:updateJob':
            setJobIcon(data.job);
            document.getElementById('jobName').textContent = capitalize(data.job);
            document.getElementById('jobGrade').textContent = data.grade || '';
            break;
        case 'hud:updateStats':
            if (data.values.health != null) setBar(document.getElementById('healthBar'), data.values.health);
            if (data.values.armor != null) setBar(document.getElementById('armorBar'), data.values.armor);
            if (data.values.thirst != null) setBar(document.getElementById('thirstBar'), data.values.thirst);
            if (data.values.hunger != null) setBar(document.getElementById('hungerBar'), data.values.hunger);
            break;
        case 'hud:show':
            document.getElementById('hud').classList.add('show');
            document.getElementById('hud').classList.remove('hidden');
            break;
        case 'hud:hide':
            document.getElementById('hud').classList.remove('show');
            document.getElementById('hud').classList.add('hidden');
            break;
    }
});

function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}

function setBar(el, value) {
    const v = Math.max(0, Math.min(100, Number(value) || 0));
    el.style.width = `${v}%`;
}
